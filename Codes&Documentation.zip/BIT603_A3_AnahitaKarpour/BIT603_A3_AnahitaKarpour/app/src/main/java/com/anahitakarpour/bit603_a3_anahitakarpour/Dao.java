package com.anahitakarpour.bit603_a3_anahitakarpour;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@androidx.room.Dao
public interface Dao {

    @Insert
    public void addItem(Item item);

    @Insert
    public void addUser(User user);

    @Query("SELECT * FROM User")
    public List<User> getUsers();

    @Query("SELECT * FROM Item")
    public List<Item> getItems();

    //Return the item if found
    @Query("SELECT Name FROM Item WHERE Name = :myItemName COLLATE NOCASE")
    public String checkForItem(String myItemName);

    //Return the user if found
    @Query("SELECT UserName FROM User WHERE UserName = :myUserName")
    public String checkForUser(String myUserName);

    //Returns the employeeNum if found
    @Query("SELECT EmployeeNumber FROM User WHERE EmployeeNumber = :myEmployeeNum")
    public int checkForEmployeeNum(int myEmployeeNum);

    @Query("UPDATE User SET Password = :myPassWord, DOB = :myDOB, " +
            "EmployeeNumber = :myEmployeeNum, PhoneNumber = :myPhoneNum, Address = :myAddress WHERE UserName = :myUserName COLLATE NOCASE")
    public void updateUser(String myUserName, String myPassWord, String myDOB, int myEmployeeNum, String myPhoneNum, String myAddress);

    @Query("UPDATE Item SET Quantity = :myQuantity, ItemType = :myItemType WHERE Name = :myItemName COLLATE NOCASE")
    public void updateItem(String myItemName, int myQuantity, long myItemType);

    //Delete a row in the User table where username is specified
    @Query("DELETE FROM User WHERE UserName = :myUserName")
    public void removeUser(String myUserName);

    //Delete a row of the Item table where item name is specified
    @Query("DELETE FROM Item WHERE Name = :myItemName COLLATE NOCASE")
    public void removeItem(String myItemName);

    //Delete all rows of the Item table
    @Query("DELETE FROM Item")
    public void removeAllItems();

}
