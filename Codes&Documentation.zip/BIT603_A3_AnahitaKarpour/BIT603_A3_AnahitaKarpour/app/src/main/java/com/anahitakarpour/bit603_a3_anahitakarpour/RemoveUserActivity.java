package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class RemoveUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_user);

        final Button myBtnRemove = findViewById(R.id.btnRemove);
        final EditText myEditTxtUser = findViewById(R.id.editTxtUserName);
        final ImageButton myImgBtnBack = findViewById(R.id.imgBtnBack);

        myBtnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myUserName;
                try {
                    //Check that the textbox is not empty
                    if (!myEditTxtUser.getText().toString().isEmpty()) {

                        //Obtain data from the interface
                        myUserName = myEditTxtUser.getText().toString();

                        //if the user does exists the user is removed after confirmation from the admin
                        if (userExists(myUserName)) {
                            //Delete the user
                            deleteUser(myUserName);
                            //clear the interface
//                            myEditTxtUser.setText("");

                            //if the user doesn't exist an appropriate message is displayed
                        } else {
                            Toast.makeText(getBaseContext(), getString(R.string.noUserFound, myUserName), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        //Show admin the warning message that they need to fill the input box.
                        myEditTxtUser.setError(getString(R.string.fillUserEditTxt));
                    }

                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });
        myImgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
            }
        });
    }

    //checks if a user with a particular username exists(case sensitive)
    private boolean userExists(String username) {
        boolean result = false;
        try {
            String myUserName = LogInActivity.companyDatabase.dao().checkForUser(username);

            if (username.equals(myUserName)) {
                result = true;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    //Removes a user details from the User table after getting confirmation via alert dialog
    private void deleteUser(final String username) {

        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(RemoveUserActivity.this);
        //Set characteristics
        builder.setMessage(getString(R.string.deleteUserMsg, username)).setTitle(R.string.deleteUserTitle);
        builder.setPositiveButton(R.string.alertDialogDeleteYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //if admin is positive delete the user
                LogInActivity.companyDatabase.dao().removeUser(username);

                //Show the confirmation to the Admin
                Toast.makeText(getBaseContext(), getString(R.string.deleteItemConfirmation, username), Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.alertDialogDeleteNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Cancel btn was clicked
            }
        });
        //Get AlertDialog
        AlertDialog dialog = builder.create();
        //Show dialog
        dialog.show();
    }
}