package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import com.google.android.material.navigation.NavigationView;

public class MenuActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    NavigationView navigationView;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        //Get a reference to the interface widgets
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navView);
        final Toolbar toolbar = findViewById(R.id.toolbar);

        //ToolBar
        setSupportActionBar(toolbar);

        //Navigation Drawer Menu
        navigationView.bringToFront();
        //To get the rotating action when the hamburger menu is clicked
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        //To make the navigation menu clickable
        navigationView.setNavigationItemSelectedListener(this);
        //if login details is admin
        if (LogInActivity.admin) {
            navigationView.getMenu().findItem(R.id.nav_manageUsers).setVisible(true);
            //On launch the Manage Users menu is selected by default
            navigationView.setCheckedItem(R.id.nav_manageUsers);
            //Keeps the Manage Users icons visible
            navigationView.getMenu().setGroupVisible(R.id.navGroup_manageUsers, true);
            //Keeps the navigation drawer open
//            drawerLayout.openDrawer(GravityCompat.START);
        }else{
            //On launch the home/welcome menu is selected by default
            navigationView.setCheckedItem(R.id.nav_welcome);
        }
    }

    //Overrides the onNavigationItemSelected() method to work with option menus
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Menu menu = navigationView.getMenu();

        switch (menuItem.getItemId()) {
            case R.id.nav_welcome:
                //hide the manage user submenus
                menu.findItem(R.id.nav_addUser).setVisible(false);
                menu.findItem(R.id.nav_removeUser).setVisible(false);
                menu.findItem(R.id.nav_viewUser).setVisible(false);
                //hide the manageInventory submenus
                menu.findItem(R.id.nav_addItem).setVisible(false);
                menu.findItem(R.id.nav_addTestItems).setVisible(false);
                menu.findItem(R.id.nav_removeItem).setVisible(false);
                menu.findItem(R.id.nav_inventoryStatus).setVisible(false);
                break;

            //User Menus
            case R.id.nav_manageUsers:
                //Show the manage user submenus
                menu.setGroupVisible(R.id.navGroup_manageUsers,true);

                //hide the manageInventory submenus
                menu.findItem(R.id.nav_addItem).setVisible(false);
                menu.findItem(R.id.nav_addTestItems).setVisible(false);
                menu.findItem(R.id.nav_removeItem).setVisible(false);
                menu.findItem(R.id.nav_inventoryStatus).setVisible(false);
                return true;

            //Add User
            case R.id.nav_addUser:
                Intent i = new Intent(getApplicationContext(), AddUserActivity.class);
                startActivity(i);
                break;
            //Remove User
            case R.id.nav_removeUser:
                Intent intentRemoveUser = new Intent(getApplicationContext(), RemoveUserActivity.class);
                startActivity(intentRemoveUser);
                break;
            //View User
            case R.id.nav_viewUser:
                Intent intent1 = new Intent(getApplicationContext(), ViewUserActivity.class);
                startActivity(intent1);
                break;

            //Inventory Menus
            case R.id.nav_manageInventory:
                //setting submenus visible state
                menu.setGroupVisible(R.id.navGroup_manageInventory,true);
               // hide the manage user submenus
                menu.findItem(R.id.nav_addUser).setVisible(false);
                menu.findItem(R.id.nav_removeUser).setVisible(false);
                menu.findItem(R.id.nav_viewUser).setVisible(false);
                return true;

            //View Inventory
            case (R.id.nav_inventoryStatus):
                Intent intentStatus = new Intent(getApplicationContext(), InventoryStatusActivity.class);
                startActivity(intentStatus);
                break;

            //Add Item
            case (R.id.nav_addItem):
                Intent intentAdd = new Intent(getApplicationContext(), AddItemActivity.class);
                startActivity(intentAdd);
                break;

            //Remove Item
            case (R.id.nav_removeItem):
                Intent intentClear = new Intent(getApplicationContext(), RemoveItemActivity.class);
                startActivity(intentClear);
                break;

            //Add Test Items
            case (R.id.nav_addTestItems):
                add20ItemConfirm();
                break;

            //Log Out
            case R.id.nav_logout:
                Intent intentLogOut = new Intent(getApplicationContext(), LogInActivity.class);
                startActivity(intentLogOut);
                break;
        }
        //close the navigation drawer after selecting the menu
        drawerLayout.closeDrawer(GravityCompat.START);
        //Item will be selected if the action is triggered
        return true;
    }


    //This function creates and adds 20 items to the database.
    private void add20Items() {
        try {
            //Since the purpose of this function is to quickly test the functionality of the app
            //and the items are assumed not expected to be translated
            //for the app in another language; the item names have not been placed in the String.xml file.
            Item itemOne = new Item("Milk", 2, ItemType.INGREDIENT);
            Item itemTwo = new Item("Sugar", 9, ItemType.INGREDIENT);
            Item itemThree = new Item("Sponge", 10, ItemType.CAKE);
            Item itemFour = new Item("Chocolate", 8, ItemType.CAKE);
            Item itemFive = new Item("Chocolate Chip", 10, ItemType.COOKIE);
            Item itemSix = new Item("Snickerdoodle", 20, ItemType.COOKIE);
            Item itemSeven = new Item("Gingersnap", 10, ItemType.COOKIE);
            Item itemEight = new Item("Chocolate Finger", 30, ItemType.BISCUIT);
            Item itemNine = new Item("Florentine", 10, ItemType.BISCUIT);
            Item itemTen = new Item("Mr Kipling Viennese Whirl", 10, ItemType.BISCUIT);
            Item itemEleven = new Item("Custard Cream", 12, ItemType.BISCUIT);
            Item itemTweleve = new Item("Black Forest", 12, ItemType.CAKE);
            Item itemThirteen = new Item("Red Velvet", 23, ItemType.CAKE);
            Item itemFourteen = new Item("Ice Cream", 2, ItemType.CAKE);
            Item itemFifteen = new Item("Baking Powder", 3, ItemType.INGREDIENT);
            Item itemSixteen = new Item("Yeast", 4, ItemType.INGREDIENT);
            Item itemSeventeen = new Item("Spatula", 9, ItemType.OTHER);
            Item itemEighteen = new Item("Whisk", 4, ItemType.OTHER);
            Item itemNineteen = new Item("Rolling Pin", 5, ItemType.OTHER);
            Item itemTwenty = new Item("Measuring Cups", 4, ItemType.OTHER);

            //Add items to the database
            LogInActivity.companyDatabase.dao().addItem(itemOne);
            LogInActivity.companyDatabase.dao().addItem(itemTwo);
            LogInActivity.companyDatabase.dao().addItem(itemThree);
            LogInActivity.companyDatabase.dao().addItem(itemFour);
            LogInActivity.companyDatabase.dao().addItem(itemFive);
            LogInActivity.companyDatabase.dao().addItem(itemSix);
            LogInActivity.companyDatabase.dao().addItem(itemSeven);
            LogInActivity.companyDatabase.dao().addItem(itemEight);
            LogInActivity.companyDatabase.dao().addItem(itemNine);
            LogInActivity.companyDatabase.dao().addItem(itemTen);
            LogInActivity.companyDatabase.dao().addItem(itemEleven);
            LogInActivity.companyDatabase.dao().addItem(itemTweleve);
            LogInActivity.companyDatabase.dao().addItem(itemThirteen);
            LogInActivity.companyDatabase.dao().addItem(itemFourteen);
            LogInActivity.companyDatabase.dao().addItem(itemFifteen);
            LogInActivity.companyDatabase.dao().addItem(itemSixteen);
            LogInActivity.companyDatabase.dao().addItem(itemSeventeen);
            LogInActivity.companyDatabase.dao().addItem(itemEighteen);
            LogInActivity.companyDatabase.dao().addItem(itemNineteen);
            LogInActivity.companyDatabase.dao().addItem(itemTwenty);

            Toast.makeText(getBaseContext(), R.string.addTestItemsConfirmation, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
    }

    //Gets confirmation from the user before adding 20items to the database
    private void add20ItemConfirm() {
        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
        //Set Characteristics
        builder.setMessage(R.string.addTestItemsMsg).setTitle(R.string.addTestItemsTitle);

        builder.setPositiveButton(R.string.alertDialogAdd, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Add 20 test items to the database
                add20Items();
            }
        });
        builder.setNegativeButton(R.string.alertDialogCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // do nothing
            }
        });
        // Get AlertDialog
        AlertDialog dialog = builder.create();

        // Show dialog
        dialog.show();
    }

    //Disables the back button so the users have to sign in and sign out
    @Override
    public void onBackPressed() {
        //do nothing
        //super.onBackPressed();
        //Not calling **super**, disables back button in current screen.
    }
}