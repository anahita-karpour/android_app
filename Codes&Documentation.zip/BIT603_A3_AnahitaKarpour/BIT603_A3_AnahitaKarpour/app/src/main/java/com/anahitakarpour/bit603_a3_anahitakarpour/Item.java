package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Item") //"Item" refers to the table name, not the class below
public class Item {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="ID")
    private int id;
    @ColumnInfo(name = "Name")
    private String name;
    @ColumnInfo(name="ItemType")
    @ItemType
    private int type;
    @ColumnInfo(name="Quantity")
    private int quantity;

    //Class constructor
    public Item(String name, int quantity, @ItemType int type){
        this.name = name;
        this.quantity = quantity;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ItemType
    public int getType() {
        return type;
    }

    public void setType(@ItemType int type) {
        this.type = type;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
