package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Item.class, User.class}, version = 1, exportSchema = false)
public abstract class KiwiDatabase extends RoomDatabase{
    public abstract Dao dao();
}
