package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AddUserActivity extends AppCompatActivity {
    EditText myEditTxtEmployeeNum;
    EditText myEditTxtDOB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        final EditText myEditTxtUserName = findViewById(R.id.editTxtUserNameAdd);
        final EditText myEditTxtPass = findViewById(R.id.editTxtAddUserPass);
        final EditText myEditTxtPhone = findViewById(R.id.editTxtPhone);
        final EditText myEditTxtAddress = findViewById(R.id.editTxtAddress);
        final Button myBtnAdd = findViewById(R.id.btnAddUser);
        final ImageButton myImgBtnBack = findViewById(R.id.imgBtnBack);
        myEditTxtEmployeeNum = findViewById(R.id.editTxtEmployeeNum);
        myEditTxtDOB = findViewById(R.id.editTextDOB);

        myBtnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //Check that all editText boxes have been filled up
                    if ((!myEditTxtUserName.getText().toString().isEmpty()) && (!myEditTxtPass.getText().toString().isEmpty()) && (!myEditTxtDOB.getText().toString().isEmpty()) &&
                            (!myEditTxtEmployeeNum.getText().toString().isEmpty()) && (!myEditTxtPhone.getText().toString().isEmpty()) && (!myEditTxtAddress.getText().toString().isEmpty())) {

                        //Obtain data from the interface
                        String username = myEditTxtUserName.getText().toString();
                        String pass = myEditTxtPass.getText().toString();
                        String dob = myEditTxtDOB.getText().toString();
                        String phone = myEditTxtPhone.getText().toString();
                        String address = myEditTxtAddress.getText().toString();
                        int employeeNum = 0;

                        try {
                            employeeNum = Integer.parseInt(myEditTxtEmployeeNum.getText().toString());
                        } catch (NumberFormatException e) {
                            myEditTxtEmployeeNum.setError(getString(R.string.employeeNumErrorMsg));
                        }
                        //Check the data from the interface is in correct format if not prompt the user
                        if (userIsValid(username) && passIsValid(pass) && dobIsValid(dob) &&
                                employeeNumIsValid(employeeNum) && phoneIsValid(phone) && addressIsValid(address)) {

                            //check if the employee Num doesn't exist in the database
                            if (!checkEmpNumExists(employeeNum)) {
                                //check if the user doesn't exist in the database add the new user
                                if (!checkUserExists(username)) {
                                    //if the user doesn't exists: add the user
                                    addUser(username, pass, dob, employeeNum, phone, address);
                                    //Clear the text
                                    myEditTxtUserName.setText("");
                                    myEditTxtPass.setText("");
                                    myEditTxtDOB.setText("");
                                    myEditTxtEmployeeNum.setText("");
                                    myEditTxtPhone.setText("");
                                    myEditTxtAddress.setText("");
                                    //if the user does exists: ask if admin wants to update it
                                } else {
                                    //if the user exists in the database ask if they want to update it
                                    updateDialog(username, pass, dob, employeeNum, phone, address);
                                }
                            } else {
                                myEditTxtEmployeeNum.setError(getString(R.string.empUniqueErrorMsg));
//                                Toast.makeText(getBaseContext(), getString(R.string.empUniqueErrorMsg), Toast.LENGTH_SHORT).show();
                            }
                        } else { //if all the data are not correct prompt the user to correct it
                            //Username
                            if (!userIsValid(username)) {
                                myEditTxtUserName.setError(getString(R.string.userNameAddErrorMsg));
                            }//password
                            if (!passIsValid(pass)) {
                                myEditTxtPass.setError(getString(R.string.passAddUserErrorMsg));
                            }//dob
                            if (!dobIsValid(dob)) {
                                myEditTxtDOB.setError(getString(R.string.dobErrorMsg));
                            }//employeeNumber
                            if (!employeeNumIsValid(employeeNum)) {
                                myEditTxtEmployeeNum.setError(getString(R.string.employeeNumErrorMsg));
                            }//phone
                            if (!phoneIsValid(phone)) {
                                myEditTxtPhone.setError(getString(R.string.phoneErrorMsg));
                            }//address
                            if (!addressIsValid(address)) {
                                myEditTxtAddress.setError(getString(R.string.addressErrorMsg));
                            }
                        }
                    } else {
                        Toast.makeText(getBaseContext(), R.string.fillAllBoxesMsg, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    //Catch any exception that may arise during the process
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });
        myImgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
            }
        });
    }

    //Add the user to the database
    private void addUser(String userName, String passWord, String dOB, int employeeNumber, String phoneNumber, String addressEmployee) {
        try {
            //create a new user object
            User user = new User();
            user.setUserName(userName);
            user.setPassword(passWord);
            user.setDOB(dOB);
            user.setEmployeeNum(employeeNumber);
            user.setPhoneNum(phoneNumber);
            user.setAddress(addressEmployee);

            //Add/Insert the user into the database
            LogInActivity.companyDatabase.dao().addUser(user);

            //Display the success message
            Toast.makeText(getBaseContext(), R.string.userAddedConfirmation, Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }

    }

    //Checks if user name already exists in the database table
    private boolean checkUserExists(String username) {
        boolean exists = false;

        try {
            String myUserName = LogInActivity.companyDatabase.dao().checkForUser(username);

            if (username.equals(myUserName)) {
                exists = true;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return exists;
    }

    //Check if the employee number already exists in the database
    private boolean checkEmpNumExists(int number) {
        boolean exists = false;

        try {
            int myEmpNumber = LogInActivity.companyDatabase.dao().checkForEmployeeNum(number);
            if (number == myEmpNumber) {
                exists = true;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return exists;
    }

    //Updates the user information in the database
    // Starts an alert dialog box with two options of Update and cancel. On pressing the update option, the user details will get updated
    private void updateDialog(final String userName, final String passWord, final String dOB, final int employeeNumber, final String phoneNumber, final String address) {
        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(AddUserActivity.this);
        //Set Characteristics
        builder.setMessage(R.string.alertDialogUserMain).setTitle(R.string.alertDialogUserTitle);

        builder.setPositiveButton(R.string.alertDialogUpdate, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Upade the user in the database
                LogInActivity.companyDatabase.dao().updateUser(userName, passWord, dOB, employeeNumber, phoneNumber, address);

                Toast.makeText(getBaseContext(), getString(R.string.successfulUpdate, userName), Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.alertDialogCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // cancel button was clicked
            }
        });
        // Get AlertDialog
        AlertDialog dialog = builder.create();

        // Show dialog
        dialog.show();
    }

    //Validates the username
    // input must contain at least 4 and at most 8 alphabetic characters only
    private boolean userIsValid(String userName) {
        boolean valid = false;
        String regex = "^([A-Za-z]{4,8})$";
//                "^" +            //represents; starting character of the string
//                "(?=[A-Za-z])" + //represents; contain only alphabetic characters
//                ".{4,8}" +       //represents; at least 4 characters and at most 8 characters
//                "$";             //represents the end of the string

        //Compile the ReGex
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(userName);
        if (m.matches()) {
            valid = true;
        }
        return valid;
    }

    //Validates the password
    // input must: contains at least one lowercase alphabet, contains at least one uppercase alphabet,
    // have no whitespace, have at least 4 characters and at most 10 characters
    //contains at least a numeric value
    private boolean passIsValid(String password) {
        boolean valid = false;

        //Regex to check for valid password
        String regex = "^" +    //represents; starting character of the string
                "(?=.*[0-9])" + //represents; contains at least one digit
                "(?=.*[a-z])" + //represents; contains at least one lowercase alphabet
                "(?=.*[A-Z])" + //represents; contains at least one uppercase alphabet
                "(?=\\S+$)" +   //represents; whitespace is not allowed in the password string
                ".{4,10}" +       //represents; at least 4 characters and at most 10 characters
                "$";            //represents the end of the string

        //Compile the ReGex
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(password);
        if (m.matches()) {
            valid = true;
        }
        return valid;
    }

    //Validates the DOB
    // input must be in the format of dd/mm/yyyy
    // input must be greater than 01/01/1920 and less than 01/01/2005
    private boolean dobIsValid(String dateOfBirth) {
        boolean valid = false;
        //Set preferred date format,
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        dateFormat.setLenient(false);

        String minYear = getString(R.string.minYear);
        String maxYear = getString(R.string.maxYear);

        // Create Date object and parse the string Date of Birth into date
        try {
            Date dobDate = dateFormat.parse(dateOfBirth);

            Date strMinDate = dateFormat.parse(minYear);
            Date strMaxDate = dateFormat.parse(maxYear);
            //make sure the date is greater than 01/01/1920 and less than 01/01/2005.
            if (dobDate != null && dobDate.after(strMinDate) && dobDate.before(strMaxDate)) {
                valid = true;
            }
        } catch (Exception e) {
           //Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
            myEditTxtDOB.setError(getString(R.string.dobErrorMsg));
        }
        return valid;
    }

    //Validates the Employee number
    //input must be at least one and at most five digits and only contain numbers.
    //input must be unique, leading zeros are ignored
    private boolean employeeNumIsValid(int employeeNumber) {
        boolean valid = false;
        String regex = "^([1-9][0-9]{0,4})$";
//                "^" +      //represents; starting character of the string
//                "(?=[1-9])"+     //first digit can be between 1-9
//                "(?= [0-9])" +    //after first digit rest can be any digits between 0 to 9
//                ".{0,4}" +        //represents; second digit can be between 0 to 4 characters
//                "$";              //represents the end of the string

        try {
            //Compile the ReGex
            Pattern pattern = Pattern.compile(regex);
            Matcher m = pattern.matcher(String.valueOf(employeeNumber));
            if (m.matches()) {
                valid = true;
            }
        }catch (Exception e){
            myEditTxtEmployeeNum.setError(getString(R.string.employeeNumErrorMsg));
        }

        return valid;
    }

    //Validates the Contact phone number
    //input must start with a zero and have 9 digit afterwards no whitespace or special characters are allowed
    private boolean phoneIsValid(String phoneNumber) {
        boolean valid = false;
        String regex = "^0[0-9]{9}$";
        //or ^0\d{9}$
//                "^" +    //represents; starting character of the string
//                "(?=0)" +       //represents; starts with zero
//                "(?=[0-9])" +   //represents; contains only digits
//                "{9}" +       //represents; contains 10 digits
//                "$";            //represents the end of the string

        //Compile the ReGex
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(phoneNumber);

        if (m.matches()) {
            valid = true;
        }
        return valid;
    }

    //Validates the Address
    //input must be at least 5 characters, characters can be numerical digits or alphabets or \ or / or - or whitespace
    private boolean addressIsValid(String address) {
        boolean valid = false;
        String regex = "^[a-zA-Z0-9\\\\/ \\-]{5,}$";
//                String regex = "^[a-zA-Z0-9\\\\/\\ \\-]{5,}$";
//                "^" +    //represents; starting character of the string
//                "(?=.*[A-Za-z]{2,})" + //represents; contains at least two alphabet character
//                ".{5,}" +       //represents; at least 5 characters
//                "$";            //represents the end of the string

        //Compile the ReGex
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(address);
        if (m.matches()) {
            valid = true;
        }
        return valid;
    }
}