package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AddItemActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    @ItemType
    int itemType = 0;
    EditText myEditTxtQuantity;
    EditText myEditTxtItemName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        //Get a reference to the widgets on the screen
        final Spinner mySpItemType = findViewById(R.id.spinnerItemType);
        myEditTxtItemName = findViewById(R.id.editTxtSingleItemName);
        myEditTxtQuantity = findViewById(R.id.editTxtItemQuantity);
        final Button myBtnAddItem = findViewById(R.id.btnAddItem);
        final ImageButton myImgBtnBack = findViewById(R.id.imgBtnBack);

        //Dropdown menu
        //Spinner Adapter uses for bind between data set and spinner widget and it manages view for the spinner row item.
        final ArrayAdapter<CharSequence> myAdapter = ArrayAdapter.createFromResource(this, R.array.inventoryItemType, android.R.layout.simple_spinner_item);
        //Set spinner dropDownView resource from android layout resources
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Set Adapter
        mySpItemType.setAdapter(myAdapter);

        mySpItemType.setOnItemSelectedListener(this);

        //Click Event for the button
        myBtnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //Check that all editText boxes/drop down menu have been filled up
                    if ((!myEditTxtItemName.getText().toString().isEmpty()) && (!myEditTxtQuantity.getText().toString().isEmpty()) && (mySpItemType.getSelectedItemId() > 0)) {

                        //Obtain data from the interface
                        String itemName = myEditTxtItemName.getText().toString();
                        int itemQuantity = 0;
                        try {
                            itemQuantity = Integer.parseInt(myEditTxtQuantity.getText().toString());
                        } catch (Exception e) {
                            myEditTxtQuantity.setError(getString(R.string.itemQuantityErrorMsg));
                        }

                        if (isQuantityValid(itemQuantity) && isItemNameValid(itemName)) {

                            //check if the item exists in the database - case insensitive
                            if (!checkItemExists(itemName)) {
                                //if the item doesn't exists: add the item
                                addItem(itemName, itemQuantity, itemType);
                                //Clear the text
                                myEditTxtItemName.setText("");
                                myEditTxtQuantity.setText("");
                                //Reset the spinner
                                mySpItemType.setSelection(0);

                                //if the item does exists: ask if user wants to update it - case insensitive
                            } else {
                                updateDialog(itemName, itemQuantity, itemType);
                            }
                        } else {
                            if (!isItemNameValid(itemName)) {
                                myEditTxtItemName.setError(getString(R.string.itemNameErrorMsg));
                            }
                            if (!isQuantityValid(itemQuantity)) {
                                myEditTxtQuantity.setError(getString(R.string.itemQuantityErrorMsg));
                            }
                            if (mySpItemType.getSelectedItemId() == 0) {
                                Toast.makeText(getBaseContext(), R.string.itemTypeErrorMsg, Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        if (myEditTxtItemName.getText().toString().isEmpty()) {
                            myEditTxtItemName.setError(getString(R.string.emptyItemNameError));
                        }
                        if (myEditTxtQuantity.getText().toString().isEmpty()) {
                            myEditTxtQuantity.setError(getString(R.string.emptyQuantityError));
                        }
                        if (mySpItemType.getSelectedItemId() == 0) {
                            Toast.makeText(getBaseContext(), R.string.itemTypeErrorMsg, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    //Catch any exception that may arise during the process
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });

        myImgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
            }
        });
    }

    //Validates item name
    //Input must be between 3 to 15 characters long, the first two letters must be alphabetic characters, can contain whitespace and - afterwards.
    private boolean isItemNameValid(String name) {
        boolean valid = false;
        String regex = "^([A-Za-z][A-Za-z][A-Za-z -]{1,13})$";
//                "^" +            //represents; starting character of the string
//                "(?=[A-Za-z/ \\-\\'])" + //represents; contain only alphabetic characters, whitespace - and '.
//                ".{2,15}" +       //represents; at least 2 characters and at most 15 characters
//                "$";             //represents the end of the string

        //Compile the ReGex
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(name);
        if (m.matches()) {
            valid = true;
        }
        return valid;
    }

    //Validates item quantity
    //Item quantity can only be numbers and one to four digit long.
    //Leading zeros are ignored.
    private boolean isQuantityValid(int quantity) {
        boolean valid = false;
        String regex = "^([1-9][0-9]{0,3})$";
//                      "^" +      //represents; starting character of the string
//                "(?=[1-9])"+     //first digit can be between 1-9
//                "(?= [0-9])" +    //after first digit rest can be any digits between 0 to 9
//                ".{0,3}" +        //represents; second digit can be between 0 to 3 characters
//                "$";              //represents the end of the string
        try {
            //Compile the ReGex
            Pattern pattern = Pattern.compile(regex);
            Matcher m = pattern.matcher(String.valueOf(quantity));
            if (m.matches()) {
                valid = true;
            }
        } catch (Exception e) {
            myEditTxtQuantity.setError(getString(R.string.employeeNumErrorMsg));
        }
        return valid;
    }

    //Adds item to the database
    private void addItem(String itemName, int itemQuantity, int itemType) {
        try {
            //create a new item object
            Item item = new Item(itemName, itemQuantity, itemType);

            //Add/Insert the item into the database
            LogInActivity.companyDatabase.dao().addItem(item);

            //Display the success message
            Toast.makeText(getBaseContext(), R.string.itemAddConfirmation, Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
    }

    //Checks if item name already exists in the database table - case insensitive
    private boolean checkItemExists(String itemName) {
        boolean result = false;

        try {
            String myItemName = LogInActivity.companyDatabase.dao().checkForItem(itemName);

            if (itemName.equalsIgnoreCase(myItemName)) {
                result = true;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    //Updates the item information in the database
    //Starts with an alert dialog box with two options of Cancel and Update. On pressing the Update option, the item details will get updated - case insensitive
    private void updateDialog(final String itemName, final int itemQuantity, @ItemType final int itemType) {
        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(AddItemActivity.this);
        //Set Characteristics
        builder.setMessage(R.string.alertDialogItemMain).setTitle(R.string.alertDialogItemTitle);

        builder.setPositiveButton(R.string.alertDialogUpdate, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Upade the user in the database
                LogInActivity.companyDatabase.dao().updateItem(itemName, itemQuantity, itemType);

                Toast.makeText(getBaseContext(), getString(R.string.successfulUpdate, itemName), Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.alertDialogCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // cancel button was clicked
            }
        });
        // Get AlertDialog
        AlertDialog dialog = builder.create();

        // Show dialog
        dialog.show();
    }

    //This method takes an input integer value that represents the chosen drop down menu option
    // and returns the corresponding integer that corresponds to the int of string for that drop down menu
    // in the string resource file
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        int itemPosition = (int) adapterView.getItemIdAtPosition(i);

        switch (itemPosition) {
            case 0:
                itemType = R.string.selectItemType;
                break;
            case 1:
                itemType = R.string.biscuit;
                break;
            case 2:
                itemType = R.string.cookie;
                break;
            case 3:
                itemType = R.string.cake;
                break;
            case 4:
                itemType = R.string.ingredient;
                break;
            case 5:
                itemType = R.string.other;

                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}