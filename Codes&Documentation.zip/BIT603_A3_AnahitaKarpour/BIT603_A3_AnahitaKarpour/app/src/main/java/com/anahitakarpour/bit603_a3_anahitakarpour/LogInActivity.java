package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class LogInActivity extends AppCompatActivity {
    public static KiwiDatabase companyDatabase;
    public static boolean admin = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        companyDatabase = Room.databaseBuilder(getApplicationContext(), KiwiDatabase.class, "companydb").allowMainThreadQueries().build();

        //Create an anchor to the widgets on the screen
        final EditText myEditTxtPass = findViewById(R.id.editTxtPassword);
        final EditText myEditTxtName = findViewById(R.id.editTxtUserName);
        final Button myBtnLogIn = findViewById(R.id.btnLogIn);

        myBtnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username;
                String password;

                try {

                    //Get the login details from the interface
                    username = myEditTxtName.getText().toString();
                    password = myEditTxtPass.getText().toString();

                    //if the username and password are not empty
                    if (!username.equals("") && !password.equals("")) {
                        //if the username and password is an admin login-Go straight to Manage User page
                        if (adminLogIn(username, password)) {
                            //set the global variable admin to true,
                            admin = true;
                            //if the login details are of admin go to the admin menu page where user can add/remove or view users
                            Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                            startActivity(intent);
                        }else if (checkLogInDetail(username, password)) {
                            admin = false;
                            Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                            startActivity(intent);
                        } else {
                            //if no match: clear the password field
                            myEditTxtPass.getText().clear();

                            //if no match: show the appropriate message and fail to log in.
                            logInErrorDialog();
                        }
                    } else {
                        //prompt the user to fill both editText boxes
                        Toast.makeText(getBaseContext(), R.string.logInErrorFillBoth, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    //Boolean function that checks if the login details are of Admin, if so returns true
    public static boolean adminLogIn(@NotNull String username, String password) {
        boolean result = false;
        String name = "Admin";
        String pass = "CookieManagement84";

        if (username.equals(name) && password.equals(pass)) {
            result = true;
        }
        return result;
    }

    //Gets a list of the current users from the database and stores them into a list
    //Checks if the users logging details are correct; if they are: returns true
    private boolean checkLogInDetail(String userName, String userPass) {

        boolean result = false;

        try {
            //Define the List and populate it with the query result from our database table
            List<User> myUsersList = companyDatabase.dao().getUsers();
                for (User user : myUsersList) {
                    String name = user.getUserName();
                    String password = user.getPassword();

                    if (userName.equals(name) && userPass.equals(password)) {
                        result = true;
                        break;
                    }
                }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    //Displays the login error dialog
    private void logInErrorDialog() {
        try {
            //Instantiate AlertDialog.Builder
            AlertDialog.Builder builder = new AlertDialog.Builder(LogInActivity.this);
            //Set the alert message characteristics
            builder.setMessage(R.string.logInErrorMsg)
                    .setTitle(R.string.logInErrorTitle);

            builder.setPositiveButton(R.string.alertDialogOk, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    // OK button was clicked
                    Toast.makeText(LogInActivity.this, R.string.logInErrorToast, Toast.LENGTH_SHORT).show();
                }
            });
            //Create the AlertDialog
            AlertDialog dialog = builder.create();

            //Show the dialog
            dialog.show();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
    }

    //Disables the back button so the users have to sign in
    @Override
    public void onBackPressed() {
        //do nothing
        //super.onBackPressed();
        //Not calling **super**, disables back button in current screen.
    }
}