package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
@IntDef({ItemType.BISCUIT, ItemType.COOKIE, ItemType.CAKE, ItemType.INGREDIENT, ItemType.OTHER})
public @interface ItemType {
    int BISCUIT = R.string.biscuit;
    int COOKIE = R.string.cookie;
    int CAKE = R.string.cake;
    int INGREDIENT = R.string.ingredient;
    int OTHER = R.string.other;
}
