package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class InventoryStatusActivity extends AppCompatActivity implements View.OnClickListener {
    public int listStartIndex = 0;
    Button myBtnNext;
    Button myBtnBack;
    ImageButton myImgBtnBack;
    TextView myTxtViewItemInvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_status);

        myTxtViewItemInvent = findViewById(R.id.txtViewInventDispaly);
        final Button myBtnRefreshInventory = findViewById(R.id.btnRefreshInvetory);
        myImgBtnBack = findViewById(R.id.imgBtnBack);
        myBtnBack = findViewById(R.id.btnBackInvent);
        myBtnNext = findViewById(R.id.btnNextInvent);

        /*Note:
        The inventory display on the interface is refreshed when the user adds/updates items.
        The 'Refresh' button also refreshes the inventory display on the interface in case of updates
        by other users.
        * */

        //Show the inventory list
        myTxtViewItemInvent.setText(displayItems(listStartIndex));
        //Make the output textView scrollable
        myTxtViewItemInvent.setMovementMethod(new ScrollingMovementMethod());

        //Calling the OnClickListener for all our buttons
        //and passing our activity itself here (this).
        //All of these btn clicks will be sent to one onClick method
        myBtnRefreshInventory.setOnClickListener(this);
        myBtnBack.setOnClickListener(this);
        myBtnNext.setOnClickListener(this);
        myImgBtnBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnRefreshInvetory:
                try {
                    //Refreshes the item list
                    myTxtViewItemInvent.setText(displayItems(listStartIndex));
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.btnNextInvent:
                listStartIndex = listStartIndex + 5;
                myTxtViewItemInvent.setText(displayItems(listStartIndex));
                break;

            case R.id.btnBackInvent:
                listStartIndex = listStartIndex - 5;
                myTxtViewItemInvent.setText(displayItems(listStartIndex));
                break;

            case R.id.imgBtnBack:
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
                break;
        }
    }

    //Takes a list of data from Item table and displays five at a time,
    private String displayItems(int startIndex) {
        String itemName;
        int itemType, itemQuantity, endIndex;
        StringBuilder output = new StringBuilder();
        List<Item> itemsList;

        try {
            //Define the List and populate it with the query result from our database table
            itemsList = LogInActivity.companyDatabase.dao().getItems();
            if (!itemsList.isEmpty()) {
                //find the start index
                if (startIndex < 0) {
                    startIndex = 0;
                }
                if (startIndex > itemsList.size()) {
                    startIndex = itemsList.size();
                }
                //find the end index
                endIndex = Math.min(startIndex + 5, itemsList.size());

                //Disable/enable Next/Back buttons accordingly
                //Next button
                if (endIndex == itemsList.size()) {
                    myBtnNext.setEnabled(false);
                } else {
                    myBtnNext.setEnabled(true);
                }
                //Back button
                if (startIndex == 0) {
                    myBtnBack.setEnabled(false);
                } else {
                    myBtnBack.setEnabled(true);
                }

                //Loop through the list with new start and end index and display the components of its object elements
                for (int i = startIndex; i < endIndex; i++) {
                    itemName = itemsList.get(i).getName();
                    itemQuantity = itemsList.get(i).getQuantity();
                    itemType = itemsList.get(i).getType();

                    //Build the output string
                    output.append(itemName).append("      ").append(itemQuantity).append("      ")
                            .append(getResources().getString(itemType)).append("      ")
                            .append("\n").append("-----------------------------------------------------\n");
                }
            } else {
                myBtnNext.setEnabled(false);
                myBtnBack.setEnabled(false);
                Toast.makeText(getBaseContext(), R.string.emptyItemTable, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return output.toString();
    }
}


