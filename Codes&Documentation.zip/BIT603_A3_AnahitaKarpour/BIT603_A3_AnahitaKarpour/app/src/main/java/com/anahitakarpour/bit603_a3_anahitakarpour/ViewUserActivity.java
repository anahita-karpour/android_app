package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ViewUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);

        final Button myBtnUserRefresh = findViewById(R.id.btnRefreshUser);
        final TextView myTxtViewUsers = findViewById(R.id.txtViewUsersList);
        final ImageButton myImgBtnBack = findViewById(R.id.imgBtnBack);

        /*Note:
        The user display on the interface is refreshed when the admin adds/updates users.
        The 'Refresh' button also refreshes the User display on the interface in case of updates
        by other admin terminals.
        * */

        //Show the Users List
        myTxtViewUsers.setText(getUsers());
        //To make the output textview scrollable
        myTxtViewUsers.setMovementMethod(new ScrollingMovementMethod());

        myBtnUserRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myTxtViewUsers.setText(getUsers());
            }
        });

        myImgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
            }
        });
    }

    //Gets a list of the users in the database; loops through the list and populates the user details,
    //saves each user details in each row and returns the output in a string
    public String getUsers() {
        String username, password, dob, phone, address;
        int employeeNumber;
        StringBuilder output = new StringBuilder();

        try {
            //Define the List and populate it with the query result from our database table
            List<User> myUserList = LogInActivity.companyDatabase.dao().getUsers();
            if (!myUserList.isEmpty()) {
                //Loop through the list and populate the user details
                for (User user : myUserList) {
                    username = user.getUserName();
                    password = user.getPassword();
                    dob = user.getDOB();
                    employeeNumber = user.getEmployeeNum();
                    phone = user.getPhoneNum();
                    address = user.getAddress();

                    //Build the output string
                    output.append(username).append("      ").append(password).append("      ")
                            .append(dob).append("      ").append(employeeNumber).append("      ")
                            .append(phone).append("      ").append(address).append("      ")
                            .append("\n").append("------------------------------------------------------\n");
                }
            } else {
                //if the database table is empty; let the user know it is empty
                Toast.makeText(getBaseContext(), R.string.emptyUserTable, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return output.toString();
    }
}