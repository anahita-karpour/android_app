package com.anahitakarpour.bit603_a3_anahitakarpour;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.List;

public class RemoveItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_item);

        final Button myBtnRemoveSingleItem = findViewById(R.id.btnRemoveSingleItem);
        final Button myBtnRemoveAllItems = findViewById(R.id.btnRemoveAllTestItems);
        final EditText myEditTxtItemName = findViewById(R.id.editTxtSingleItemName);
        final ImageButton myImgBtnBack = findViewById(R.id.imgBtnBack);


        myBtnRemoveSingleItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myItemName;
                try {
                    //Check that the textbox is not empty
                    if (!myEditTxtItemName.getText().toString().isEmpty()) {

                        //Obtain data from the interface
                        myItemName = myEditTxtItemName.getText().toString();

                        //if the item does exists the item is removed after confirmation from the user: example a Yes/No message box
                        if (itemExists(myItemName)) {
                            //Delete the item
                            deleteItem(myItemName);
                            //Clear the interface
                           //myEditTxtItemName.setText("");
                            //if the user doesn't exist an appropriate message is displayed
                        } else {
                            Toast.makeText(getBaseContext(), getString(R.string.noItemFound, myItemName), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        //Show admin the warning message that they need to fill the input box.
                        Toast.makeText(getBaseContext(), R.string.fillItemEditTxt, Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });

        myBtnRemoveAllItems.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                try {
                    List<Item> itemList= LogInActivity.companyDatabase.dao().getItems();
                    //check item table is not empty
                    if(!itemList.isEmpty()) {
                        deleteAllItems();
                    }else{
                        Toast.makeText(getBaseContext(),R.string.emptyItemTable,Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
                }
            }
        });
        myImgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Return to the main Menu
                Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(i);
            }
        });
    }


    //checks if an item with a particular name exists - case in sensitive
    private boolean itemExists(String itemName) {
        boolean result = false;
        try {
            String myItemName = LogInActivity.companyDatabase.dao().checkForItem(itemName);

            if (itemName.equalsIgnoreCase(myItemName)) {
                result = true;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), getString(R.string.exception, e), Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    //Removes an item from the Item table after getting confirmation via alert dialog - case insensitive.
    private void deleteItem(final String itemName) {
        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(RemoveItemActivity.this);
        //Set characteristics
        builder.setMessage(getString(R.string.deleteItemMsg, itemName)).setTitle(R.string.deleteItemTitle);
        builder.setPositiveButton(R.string.alertDialogDeleteYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //if user is positive delete the item
                LogInActivity.companyDatabase.dao().removeItem(itemName);

                //Show the confirmation to the user
                Toast.makeText(getBaseContext(), getString(R.string.deleteItemConfirmation, itemName), Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.alertDialogDeleteNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Cancel btn was clicked
            }
        });
        //Get AlertDialog
        AlertDialog dialog = builder.create();
        //Show dialog
        dialog.show();

    }

    //Remove all items from the Item table after getting confirmation via alert dialog
    private void deleteAllItems() {
        //Instantiate a new AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(RemoveItemActivity.this);
        //Set characteristics
        builder.setMessage(R.string.deleteAllItemsMsg).setTitle(R.string.deleteAllItemsTitle);
        builder.setPositiveButton(R.string.alertDialogDeleteYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //if user is positive delete all the items
                LogInActivity.companyDatabase.dao().removeAllItems();

                //Show the confirmation to the user
                Toast.makeText(getBaseContext(), R.string.deleteAllItemConfirmation, Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.alertDialogDeleteNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Cancel btn was clicked
            }
        });
        //Get AlertDialog
        AlertDialog dialog = builder.create();
        //Show dialog
        dialog.show();

    }
}