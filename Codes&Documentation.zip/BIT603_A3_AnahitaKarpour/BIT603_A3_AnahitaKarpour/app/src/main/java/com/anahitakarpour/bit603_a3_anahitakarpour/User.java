package com.anahitakarpour.bit603_a3_anahitakarpour;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;


@Entity(tableName = "User", indices = {@Index(value = {"EmployeeNumber"}, unique = true)}) //"User" refers to the table name, not the class below
public class User {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ID")
    private int id;
    @ColumnInfo(name = "UserName")
    private String userName;
    @ColumnInfo(name = "Password")
    private String password;
    @ColumnInfo(name = "DOB")
    private String DOB;
    @ColumnInfo(name="EmployeeNumber")
    private int employeeNum;
    @ColumnInfo(name = "PhoneNumber")
    private String phoneNum;
    @ColumnInfo(name = "Address")
    private String address;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public void setEmployeeNum(int employeeNum) {
        this.employeeNum = employeeNum;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
